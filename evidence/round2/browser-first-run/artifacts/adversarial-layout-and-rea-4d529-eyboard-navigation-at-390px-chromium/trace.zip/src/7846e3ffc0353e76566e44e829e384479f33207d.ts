import { test, expect, type Page } from '@playwright/test';

interface TransportRequest { requestId: number; id: string; range?: { min: number; max: number } }
interface QueuedReply { request: TransportRequest; deliver: () => void }
interface WorkerGate {
  blocked: boolean;
  queue: QueuedReply[];
  deliveries: TransportRequest[];
  release: (id: string, min?: number) => number;
}
declare global { interface Window { __soupWorkerGate: WorkerGate } }

/** Control delivery of real worker responses, not a replacement data source. The
 * production client/React/query cache receive genuine generated measurements in
 * a deliberately hostile order. No hook or debug mode is shipped in the app. */
async function installWorkerGate(page: Page) {
  await page.addInitScript(() => {
    const NativeWorker = window.Worker;
    const gate: WorkerGate = {
      blocked: false,
      queue: [],
      deliveries: [],
      release(id, min) {
        const selected = this.queue.filter(reply => reply.request.id === id && (min === undefined || reply.request.range?.min === min));
        this.queue = this.queue.filter(reply => !selected.includes(reply));
        selected.forEach(reply => reply.deliver());
        return selected.length;
      },
    };
    window.__soupWorkerGate = gate;
    class DeliveryControlledWorker extends NativeWorker {
      private deliveredMessage: ((this: Worker, event: MessageEvent) => unknown) | null = null;
      private requests = new Map<number, TransportRequest>();
      constructor(url: string | URL, options?: WorkerOptions) {
        super(url, options);
        super.addEventListener('message', event => {
          const request = this.requests.get(event.data?.requestId);
          if (!request) return;
          const deliver = () => {
            gate.deliveries.push(request);
            this.deliveredMessage?.call(this, new MessageEvent('message', { data: event.data }));
          };
          if (gate.blocked) gate.queue.push({ request, deliver });
          else deliver();
        });
      }
      override get onmessage() { return this.deliveredMessage; }
      override set onmessage(listener) { this.deliveredMessage = listener; }
      override postMessage(message: TransportRequest) {
        this.requests.set(message.requestId, message);
        super.postMessage(message);
      }
    }
    window.Worker = DeliveryControlledWorker;
  });
}
async function openReady(page: Page, id = 'run-001', suffix = '') {
  await page.goto(`/#/runs/${id}${suffix}`);
  await expect(page.locator(`[data-run-id="${id}"]`)).toHaveAttribute('data-ready', 'true');
  await expect(page.getByTestId('chart-loss')).toBeVisible();
}
async function awaitQueued(page: Page, id: string, min?: number) {
  await expect.poll(() => page.evaluate(({ id, min }) => window.__soupWorkerGate.queue.filter(reply => reply.request.id === id && (min === undefined || reply.request.range?.min === min)).length, { id, min })).toBeGreaterThan(0);
}
async function renderedFrames(page: Page) {
  await page.evaluate(() => new Promise<void>(resolve => requestAnimationFrame(() => requestAnimationFrame(() => resolve()))));
}

test('actual React route keeps old-run data out while real worker replies arrive in reverse selection order', async ({ page }) => {
  await installWorkerGate(page);
  await openReady(page);
  await page.evaluate(() => { window.__soupWorkerGate.blocked = true; });
  await page.getByRole('button', { name: 'Next run', exact: true }).click();
  await expect(page.getByRole('heading', { name: 'mistral-7b-instruct-v3' })).toBeVisible();
  await expect(page.getByTestId('chart-loss')).toHaveCount(0);
  await expect(page.getByRole('status', { name: 'Loading run metrics' })).toBeVisible();
  await awaitQueued(page, 'run-002');
  await page.getByRole('button', { name: 'Next run', exact: true }).click();
  await awaitQueued(page, 'run-003');
  await expect(page.getByRole('heading', { name: 'bert-base-sentiment' })).toBeVisible();
  await expect(page.getByTestId('chart-loss')).toHaveCount(0);
  const released = await page.evaluate(() => window.__soupWorkerGate.release('run-003'));
  expect(released).toBeGreaterThan(0);
  await expect(page.locator('[data-run-id="run-003"]')).toHaveAttribute('data-ready', 'true');
  await expect(page.locator('.detail-stats .overview-card').first()).toContainText('0.2581');
  await expect(page.getByTestId('chart-loss')).toHaveAttribute('data-source-points', '11400');
  await page.evaluate(() => window.__soupWorkerGate.release('run-002'));
  await renderedFrames(page);
  await expect(page.getByRole('heading', { name: 'bert-base-sentiment' })).toBeVisible();
  await expect(page.locator('.detail-stats .overview-card').first()).toContainText('0.2581');
  await expect(page.getByTestId('chart-loss')).toHaveAttribute('data-source-points', '11400');
  await expect(page.locator('.metric-chart--loss')).toContainText('11 non-finite');
  const deliveryIds = await page.evaluate(() => window.__soupWorkerGate.deliveries.map(request => request.id));
  expect(deliveryIds.lastIndexOf('run-002')).toBeGreaterThan(deliveryIds.lastIndexOf('run-003'));
});

test('superseded same-run range cannot overwrite a newer zoom when its genuine response arrives late', async ({ page }) => {
  await installWorkerGate(page);
  await openReady(page);
  await page.evaluate(() => { window.__soupWorkerGate.blocked = true; location.hash = '/runs/run-001?min=100&max=200'; });
  await awaitQueued(page, 'run-001', 100);
  await page.evaluate(() => { location.hash = '/runs/run-001?min=499999&max=500001'; });
  await awaitQueued(page, 'run-001', 499999);
  await page.evaluate(() => window.__soupWorkerGate.release('run-001', 499999));
  await expect(page.locator('[data-run-id="run-001"]')).toHaveAttribute('data-ready', 'true');
  await expect(page.getByRole('spinbutton', { name: 'Start step' })).toHaveValue('499999');
  await expect(page.getByTestId('chart-loss')).toHaveAttribute('data-source-points', '3');
  await expect(page.getByTestId('chart-loss')).toHaveAttribute('data-max-value', '9.4');
  await page.evaluate(() => window.__soupWorkerGate.release('run-001', 100));
  await renderedFrames(page);
  await expect(page.getByRole('spinbutton', { name: 'Start step' })).toHaveValue('499999');
  await expect(page.getByTestId('chart-loss')).toHaveAttribute('data-source-points', '3');
  await expect(page.getByTestId('chart-grad_norm')).toHaveAttribute('data-source-points', '3');
  await expect(page.getByTestId('chart-lr')).toHaveAttribute('data-source-points', '3');
});

test('dragging an auxiliary chart sets the same numeric viewport on all metrics and double-click resets all', async ({ page }) => {
  await openReady(page);
  const surface = page.getByTestId('chart-grad_norm').locator('.u-over');
  await surface.scrollIntoViewIfNeeded();
  const bounds = await surface.boundingBox();
  expect(bounds).not.toBeNull();
  await page.mouse.move(bounds!.x + bounds!.width * 0.35, bounds!.y + bounds!.height * 0.5);
  await page.mouse.down();
  await page.mouse.move(bounds!.x + bounds!.width * 0.65, bounds!.y + bounds!.height * 0.5, { steps: 12 });
  await page.mouse.up();
  await expect(page).toHaveURL(/min=/);
  await expect(page.locator('[data-ready="true"]')).toBeVisible();
  const from = Number(await page.getByRole('spinbutton', { name: 'Start step' }).inputValue());
  const to = Number(await page.getByRole('spinbutton', { name: 'End step' }).inputValue());
  expect(from).toBeGreaterThan(300000);
  expect(from).toBeLessThan(400000);
  expect(to).toBeGreaterThan(600000);
  expect(to).toBeLessThan(700000);
  for (const metric of ['loss', 'lr', 'grad_norm']) {
    const chart = page.getByTestId(`chart-${metric}`);
    await expect(chart).toHaveAttribute('data-source-points', String(to - from + 1));
    await expect(chart).toHaveAttribute('data-x-min', String(from));
    await expect(chart).toHaveAttribute('data-x-max', String(to));
  }
  await expect(page.getByTestId('chart-loss')).toHaveAttribute('data-max-value', '9.4');
  await page.getByTestId('chart-lr').locator('.u-over').dblclick();
  await expect(page.locator('[data-ready="true"]')).toBeVisible();
  for (const metric of ['loss', 'lr', 'grad_norm']) {
    await expect(page.getByTestId(`chart-${metric}`)).toHaveAttribute('data-source-points', '1000000');
    await expect(page.getByTestId(`chart-${metric}`)).toHaveAttribute('data-x-min', '0');
    await expect(page.getByTestId(`chart-${metric}`)).toHaveAttribute('data-x-max', '999999');
  }
});

test('chart keyboard zoom and roving tabs remain usable without a pointer', async ({ page }) => {
  await openReady(page, 'run-009');
  const chart = page.getByTestId('chart-loss');
  await chart.focus();
  await page.keyboard.press('+');
  await expect(page).toHaveURL(/min=/);
  await expect(page.locator('[data-ready="true"]')).toBeVisible();
  await chart.focus();
  await page.keyboard.press('Home');
  await expect(page.locator('.metric-chart--loss .metric-chart__tooltip')).toContainText('Sampled step');
  await page.keyboard.press('End');
  await expect(page.locator('.metric-chart--loss .metric-chart__tooltip')).toContainText('16,199');
  await page.getByRole('tab', { name: 'Metrics', exact: true }).focus();
  await page.keyboard.press('ArrowRight');
  await expect(page.getByRole('tab', { name: /Data quality/ })).toHaveAttribute('aria-selected', 'true');
  await expect(page.getByRole('tab', { name: /Data quality/ })).toBeFocused();
  await page.keyboard.press('ArrowRight');
  await expect(page.getByRole('tab', { name: 'Run details', exact: true })).toBeFocused();
  await expect(page.getByRole('tabpanel')).toContainText('Static snapshot');
  await page.keyboard.press('ArrowLeft');
  await expect(page.getByRole('tab', { name: /Data quality/ })).toBeFocused();
});

test('search dialog traps focus in both directions and returns focus to the trigger on Escape', async ({ page }) => {
  await page.goto('/#/');
  const trigger = page.getByRole('button', { name: 'Search runs', exact: true });
  await trigger.click();
  const search = page.getByRole('textbox', { name: 'Find a training run' });
  await expect(search).toBeFocused();
  await page.keyboard.press('Shift+Tab');
  const lastResult = page.getByRole('dialog').getByRole('button').last();
  await expect(lastResult).toBeFocused();
  await page.keyboard.press('Tab');
  await expect(search).toBeFocused();
  await search.fill('absolutely-no-matching-run');
  await page.keyboard.press('Tab');
  await expect(page.getByRole('button', { name: 'Close search' })).toBeFocused();
  await page.keyboard.press('Tab');
  await expect(search).toBeFocused();
  await page.keyboard.press('Escape');
  await expect(page.getByRole('dialog')).toHaveCount(0);
  await expect(trigger).toBeFocused();
});

test('bookmark survives reload and stays isolated by run, then can be removed', async ({ page }) => {
  await openReady(page, 'run-009');
  await page.getByRole('button', { name: 'Save run', exact: true }).click();
  await expect(page.getByRole('button', { name: 'Unsave run', exact: true })).toHaveAttribute('aria-pressed', 'true');
  await page.reload();
  await expect(page.getByRole('button', { name: 'Unsave run', exact: true })).toHaveAttribute('aria-pressed', 'true');
  await page.getByRole('button', { name: 'Next run', exact: true }).click();
  await expect(page.getByRole('button', { name: 'Save run', exact: true })).toHaveAttribute('aria-pressed', 'false');
  await page.getByRole('button', { name: 'Previous run', exact: true }).click();
  await page.getByRole('button', { name: 'Unsave run', exact: true }).click();
  await page.reload();
  await expect(page.getByRole('button', { name: 'Save run', exact: true })).toHaveAttribute('aria-pressed', 'false');
});

test('unavailable browser storage reports failed saving without a false saved state', async ({ page }) => {
  await page.addInitScript(() => { Storage.prototype.setItem = () => { throw new DOMException('Storage is disabled.', 'SecurityError'); }; });
  await openReady(page, 'run-009');
  await page.getByRole('button', { name: 'Save run', exact: true }).click();
  await expect(page.getByRole('status').filter({ hasText: 'could not save' })).toBeVisible();
  await expect(page.getByRole('button', { name: 'Save run', exact: true })).toHaveAttribute('aria-pressed', 'false');
});

test('invalid URL range is disclosed and reset restores the full recorded domain', async ({ page }) => {
  await openReady(page, 'run-009', '?min=-5&max=999999');
  await expect(page.getByRole('alert')).toContainText('outside this run');
  await expect(page.getByRole('spinbutton', { name: 'Start step' })).toHaveValue('0');
  await expect(page.getByRole('spinbutton', { name: 'End step' })).toHaveValue('21599');
  await page.getByRole('button', { name: 'Reset range', exact: true }).click();
  await expect(page).not.toHaveURL(/min=/);
  await expect(page.getByRole('alert')).toHaveCount(0);
  await expect(page.getByTestId('chart-loss')).toHaveAttribute('data-source-points', '21600');
});

for (const width of [320, 390, 768]) {
  test(`layout and reachable keyboard navigation at ${width}px`, async ({ page }) => {
    await page.setViewportSize({ width, height: 844 });
    await page.goto('/#/guide');
    await expect(page.getByRole('heading', { name: 'Look closer. Keep the signal.' })).toBeVisible();
    expect(await page.evaluate(() => document.documentElement.scrollWidth)).toBeLessThanOrEqual(width);
    if (width < 760) {
      await page.keyboard.press('Tab');
      await expect(page.getByRole('link', { name: 'Skip to content' })).toBeFocused();
      await page.keyboard.press('Tab');
      await expect(page.getByRole('button', { name: 'Open navigation' })).toBeFocused();
    }
    await openReady(page);
    expect(await page.evaluate(() => document.documentElement.scrollWidth)).toBeLessThanOrEqual(width);
    await expect(page.getByTestId('chart-loss')).toBeVisible();
  });
}

test.describe('high-density display', () => {
  test.use({ deviceScaleFactor: 2, viewport: { width: 1280, height: 900 } });
  test('the million-point curve remains usable and spike inspectable at DPR2', async ({ page }) => {
    await openReady(page);
    await page.getByRole('button', { name: 'Inspect spike', exact: true }).click();
    await expect(page.locator('[data-ready="true"]')).toBeVisible();
    await expect(page.getByTestId('chart-loss')).toHaveAttribute('data-max-value', '9.4');
    await page.getByTestId('chart-loss').focus();
    await page.keyboard.press('Home');
    await expect(page.locator('.metric-chart--loss .metric-chart__tooltip')).toContainText('490,000');
    const canvas = page.getByTestId('chart-loss').locator('canvas').first();
    expect(await canvas.evaluate(node => (node as HTMLCanvasElement).width)).toBeGreaterThan(await canvas.evaluate(node => node.getBoundingClientRect().width * 1.9));
  });
});
